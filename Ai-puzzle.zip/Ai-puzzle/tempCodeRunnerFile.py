# gui.py
import tkinter as tk
import time
import random
from A_star import astar, get_neighbors, GOAL

class PuzzleGUI:
    def __init__(self, root):
        self.root = root
        root.title("🎀 8-Puzzle Game")
        root.configure(bg="#fffcfe")

        self.state = self.shuffle_state()

        title = tk.Label(
            root, text="8-Puzzle Game",
            font=("Arial", 22, "bold"),
            bg="#ffffff", fg="#580929"
        )
        title.grid(row=0, column=0, columnspan=3, pady=12)

        self.buttons = []
        for i in range(9):
            btn = tk.Button(
                root, font=("Arial", 18, "bold"),
                width=4, height=2,
                command=lambda i=i: self.click(i)
            )
            btn.grid(row=1+i//3, column=i%3, padx=6, pady=6)
            self.buttons.append(btn)

        control = tk.Frame(root, bg="#ffffff")
        control.grid(row=5, column=0, columnspan=3, pady=12)

        tk.Button(control, text="Solve", command=self.solve).grid(row=0, column=0, padx=6)
        tk.Button(control, text="Shuffle", command=self.shuffle).grid(row=0, column=1, padx=6)
        tk.Button(control, text="Reset", command=self.reset).grid(row=0, column=2, padx=6)

        self.update_gui()

    def update_gui(self):
        for i, val in enumerate(self.state):
            if val == 0:
                self.buttons[i].config(text="", bg="#c97a9a")
            else:
                self.buttons[i].config(text=str(val), bg="#f2a7c6")

        if self.state == GOAL:
            self.show_win()

    def click(self, idx):
        zero = self.state.index(0)
        if abs(zero//3 - idx//3) + abs(zero%3 - idx%3) == 1:
            s = list(self.state)
            s[zero], s[idx] = s[idx], s[zero]
            self.state = tuple(s)
            self.update_gui()

    def solve(self):
        path = astar(self.state)
        if path:
            for step in path:
                self.state = step
                self.update_gui()
                self.root.update()
                time.sleep(0.3)

    def show_win(self):
        win = tk.Toplevel(self.root)
        tk.Label(win, text="🎉 Puzzle Solved!", font=("Arial",18)).pack(padx=20, pady=20)

    def shuffle_state(self):
        s = list(GOAL)
        for _ in range(30):
            s = list(random.choice(get_neighbors(tuple(s))))
        return tuple(s)

    def shuffle(self):
        self.state = self.shuffle_state()
        self.update_gui()

    def reset(self):
        self.state = GOAL
        self.update_gui()

if __name__ == "__main__":
    root = tk.Tk()
    app = PuzzleGUI(root)

    def key(event):
        zero = app.state.index(0)
        r, c = zero//3, zero%3
        move = {"w":(-1,0), "s":(1,0), "a":(0,-1), "d":(0,1)}
        if event.char.lower() in move:
            dr, dc = move[event.char.lower()]
            nr, nc = r+dr, c+dc
            if 0 <= nr < 3 and 0 <= nc < 3:
                ni = nr*3 + nc
                s = list(app.state)
                s[zero], s[ni] = s[ni], s[zero]
                app.state = tuple(s)
                app.update_gui()

    root.bind("<Key>", key)
    root.mainloop()